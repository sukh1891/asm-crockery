<?php
session_start();
require_once '../../config/db.php';
require_once '../../includes/functions.php';

header('Content-Type: application/json');

$cartId = intval($_POST['cart_id'] ?? 0);
$qty    = max(1, intval($_POST['qty'] ?? 1));

if (!$cartId) {
    echo json_encode(['success' => false]);
    exit;
}

$userId = getLoggedInUserId();
$sid    = getSessionId();

$where = $userId
    ? "id='$cartId' AND user_id='".intval($userId)."'"
    : "id='$cartId' AND session_id='".mysqli_real_escape_string($conn,$sid)."'";

mysqli_query($conn,"
    UPDATE cart
    SET qty='$qty'
    WHERE $where
");

echo json_encode(['success' => true]);
