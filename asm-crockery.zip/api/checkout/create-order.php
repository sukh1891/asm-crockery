<?php
session_start();
ini_set('display_errors', 0);
error_reporting(0);

require_once '../../vendor/autoload.php';
require_once '../../config/db.php';
require_once '../../config/keys.php';
require_once '../../includes/functions.php';

use Razorpay\Api\Api;

header('Content-Type: application/json');

/* =====================
   CART VALIDATION
===================== */
$cartSummary = getCartSummary($conn);

if (empty($cartSummary['items'])) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Cart is empty'
    ]);
    exit;
}

/* =====================
   CUSTOMER DATA
===================== */
$name    = trim($_POST['name'] ?? '');
$email   = trim($_POST['email'] ?? '');
$phone   = trim($_POST['phone'] ?? '');
$address = trim($_POST['address'] ?? '');
$country = trim($_POST['country'] ?? 'India');

if (!$name || !$email || !$phone || !$address) {
    http_response_code(422);
    echo json_encode([
        'success' => false,
        'message' => 'Missing required checkout details'
    ]);
    exit;
}

/* =====================
   TOTAL AMOUNT
===================== */
$totalAmount = $cartSummary['total'];

if ($totalAmount <= 0) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Invalid order amount'
    ]);
    exit;
}

/* =====================
   CREATE RAZORPAY ORDER
===================== */
try {
    $api = new Api(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET);

    $razorpayOrder = $api->order->create([
        'receipt'         => 'ASM_' . time(),
        'amount'          => intval(round($totalAmount * 100)), // paise
        'currency'        => 'INR',
        'payment_capture' => 1
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Unable to initiate payment'
    ]);
    exit;
}

/* =====================
   INSERT PENDING ORDER
===================== */
$stmt = $conn->prepare("
    INSERT INTO orders
    (name, phone, email, address, country,
     total_amount, shipping_amount, currency,
     status, gateway_order_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'INR', 'pending', ?)
");

$stmt->bind_param(
    "sssssdds",
    $name,
    $phone,
    $email,
    $address,
    $country,
    $cartSummary['total'],
    $cartSummary['shipping'],
    $razorpayOrder->id
);

$stmt->execute();

$_SESSION['pending_order_id'] = $stmt->insert_id;

/* =====================
   RESPONSE
===================== */
echo json_encode([
    'success'   => true,
    'order_id'  => $razorpayOrder->id,
    'amount'    => intval(round($totalAmount * 100)),
    'currency'  => 'INR',
    'customer'  => [
        'name'  => $name,
        'email' => $email,
        'phone' => $phone
    ]
]);
