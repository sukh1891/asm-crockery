<?php
$host = "localhost";
$user = "u139684396_asm_store";
$pass = "Y7s2>CEWn/";
$db_name = "u139684396_asm_store";

$conn = mysqli_connect($host, $user, $pass, $db_name);

if (!$conn) {
    die("Database Connection Failed!");
}
?>