<?php
define("RAZORPAY_KEY_ID", "rzp_live_3Eo0BWuYZUGqhA");
define("RAZORPAY_KEY_SECRET", "jD6BiwsinKNtH2Yqe7lBohVP");
define("RAZORPAY_WEBHOOK_SECRET", "ASMwebhook@123"); // To Be Created

$PAYPAL_CLIENT_ID = "YOUR_PAYPAL_CLIENT_ID";
$PAYPAL_SECRET = "YOUR_PAYPAL_SECRET";
$PAYPAL_WEBHOOK_ID = "YOUR_PAYPAL_WEBHOOK_ID";

/* SMTP config for PHPMailer */
$SMTP_HOST   = "smtp.example.com";
$SMTP_USER   = "no-reply@example.com";
$SMTP_PASS   = "your-smtp-password";
$SMTP_PORT   = 587;                // 587 for TLS, 465 for SSL
$SMTP_SECURE = "tls";              // 'tls' or 'ssl'
$FROM_EMAIL  = "no-reply@example.com";
$FROM_NAME   = "ASM Crockery";
$ADMIN_EMAIL = "orders@example.com";